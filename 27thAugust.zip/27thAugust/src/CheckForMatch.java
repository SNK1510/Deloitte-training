
public class CheckForMatch 
{
  public static void main(String args[])
  {
	  int[] arr1;
	  arr1 =new int[]{7,2,3,4,5};
	  int[] arr2= {7,9,9,9,5};
	  System.out.println("First array!");
	  for(int i=0;i<arr1.length;i++)
	  {
		  System.out.print(arr1[i]+" ");
	  }
	  System.out.println();
	  System.out.println("Second array!");
	  for(int i=0;i<arr2.length;i++)
	  {
		  System.out.print(arr2[i]+" ");
	  }
	  System.out.println();
	  //prints right
	  int[] arr3=new int[5];
	  int count=0;
	  
	  for(int i=0;i<arr1.length;i++)
	  {
		  for(int j=0;j<arr2.length;j++)
		  {
			  if(arr1[i]==arr2[j])
			  {
				  
				  arr3[count]=arr1[i];
				  int i1=i;
				  int j1=j;
				 while(i1<arr1.length-1)
				 {
					  arr1[i1]=arr1[i1+1];
					  i1++;
				  }
				  while(j1<arr1.length-1)
				  {
					  arr2[j1]=arr2[j+1];
					  j1++;
				  }
					  count++; 
			  }
			  
		  }
	  }
	  System.out.println("This is the first array");
		  for(int i=0;i<arr1.length;i++)
		  {
			  System.out.print(arr1[i]+" ");
		  }
		  System.out.println();
		  System.out.println("This is the second array");
		  for(int i=0;i<arr2.length;i++)
		  {
			  System.out.print(arr2[i]+" ");
		  
	      }
		  System.out.println();
		  System.out.println("This is the common elements array");
		  for(int i=0;i<arr3.length;i++)
		  {
			  System.out.print(arr3[i]+" ");
		  
	      }
	  
  }
}
