import java.util.Scanner;

public class FunctionAssignment 
{
    static final String firstname="Srinanda";
    static final String lastname="Kurapati";
	public static String method1(String name)
   {
		String problem="some problem";
	   switch(name)
	   {
	   case firstname:return lastname;
	   //break;
	   case lastname:return firstname;
	   //break; //damn important.Break is useless as return returns control.
	   default:
		   return "not possible";
	   }
	   //return problem;
	   
   }
	
	
	public static void main(String args[])
   {
	   System.out.println("Please enter either your firstname or lastname");
	   Scanner sc=new Scanner(System.in);
	   String name=sc.nextLine();
	   if(name.equals(firstname))
	   {
		System.out.println("Your lastname is:"+method1(name));
	   }
	   if(name.equals(lastname))
	   {
		System.out.println("Your firstname is:"+method1(name));
	   }
   }
	   
   }

