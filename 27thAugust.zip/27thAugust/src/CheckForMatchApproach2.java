import java.util.ArrayList;

public class CheckForMatchApproach2 
{

	public static void main(String[] args)
	{
		
        ArrayList<Integer> arr1=new ArrayList<Integer>();
        arr1.add(1);
        arr1.add(2);
        arr1.add(3);
        arr1.add(4);
        arr1.add(5);
        ArrayList<Integer> arr2=new ArrayList<Integer>();
        arr2.add(1);
        arr2.add(2);
        arr2.add(9);
        arr2.add(8);
        arr2.add(7);
        ArrayList<Integer> arr3=new ArrayList<Integer>();
        for(int i=0;i<arr1.size();i++)
  	  {
  		  for(int j=0;j<arr2.size();j++)
  		  {
  			  if((arr1.get(i).equals(arr2.get(j))))
  			  {
  				  
  				 arr3.add(arr1.get(i));
  				  arr1.remove(i);
  				  arr2.remove(j);
  				  --j; // This fixed it !!!
  				 
  			  
  		  }
  	  }
  	  }
  	  System.out.println("This is the first array");
  		  for(int i=0;i<arr1.size();i++)
  		  {
  			  System.out.print(arr1.get(i)+" ");
  		  }
  		  System.out.println();
  		  System.out.println("This is the second array");
  		  for(int i=0;i<arr2.size();i++)
  		  {
  			  System.out.print(arr2.get(i)+" ");
  		  
  	      }
  		  System.out.println();
  		  System.out.println("This is the common elements array");
  		  for(int i=0;i<arr3.size();i++)
  		  {
  			  System.out.print(arr3.get(i)+" ");
  		  
  	      }

	}

}


  				/*  System.out.println("yesy");
  			  }
  		  }
  	  }
	}
}*/